// fconfig.js
const firebaseConfig = {
  apiKey: "AIzaSyCBpPuPtShcAnDymIZME2cZgcGZhRzveQU",
  authDomain: "meterdash-1f8a5.firebaseapp.com",
  projectId: "meterdash-1f8a5",
  storageBucket: "meterdash-1f8a5.appspot.com",
  messagingSenderId: "715517578674",
  appId: "1:715517578674:web:9e2f04dfd47260906928ab"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();